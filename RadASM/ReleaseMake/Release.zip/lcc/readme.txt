
Lcc needs the following in registry:

HKEY_CURRENT_USER\Software\lcc\Compiler\includepath=C:\lcc\include
HKEY_CURRENT_USER\Software\lcc\lcclnk\libpath=C:\lcc\lib

You can run the included lcc.reg file or simply start the wedit editor.

KetilO
