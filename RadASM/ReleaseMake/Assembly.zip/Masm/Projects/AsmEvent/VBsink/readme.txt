The sample test app was built in Visual Basic 6.0

The MyCom3.dll should be registered before loading the test app.

ernie@surfree.com

