// Have the headers pass the DLL names to GoLink
#DEFINE LINKFILES

#DEFINE WIN32_LEAN_AND_MEAN

// include files
#include "Windows.h"
#include "shlobj.h"
#include "Radasm\AddIns.h" ; RadAsm plugin definitions

