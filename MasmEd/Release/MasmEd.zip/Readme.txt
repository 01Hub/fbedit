MasmEd
------

Make:
-----
Before you can make your project you must select a mainfile.
You do this with Make / Set Current as Mainfile.
Selected mainfile will be shown in statusbar.

Session files:
--------------
If you work with several projects, then using session files makes life easier.

A session file contains:
1. Open files and caret position.
2. Mainfile.
3. Make options.
4. Filebrowser folder.

If you associate .mes (MasmEd session) files with MasmEd you can double click
on the .mes file in explorer to have it opened in MasmEd.
Current session file will be shown in statusbar.

On the file menu these menu items are for maintaining session files.

Open Session:
This will close the current session and open a new.

Save Session:
This will overwrite existing or create a new session file.

Close Session
This will close the current session.

Adding a new color theme:
-------------------------
1. Optional. Select a theme close to what you want.
2. Optional. Change the colors and font options.
3. Push [Add New]
4. Type in a name for the theme.
5. Push [Update] and the theme will be added to the combobox using the current colors.
6. Push [OK] or [Apply] and your new theme will be saved.

There can be max 10 themes.

Adding help files to Help menu:
-------------------------------
Use Option / Help menu to add help files.
NOTE!
The first help file must be the Win32.hlp file for F1 to work properly.
Example:
Menu item: Win32 api
Command: C:\masm32\help\WIN32.HLP

Adding tools to Tools menu:
---------------------------
Use Option / Tools menu to add tools.
Example:
Menu item: Calculator
Command: calc.exe

KetilO